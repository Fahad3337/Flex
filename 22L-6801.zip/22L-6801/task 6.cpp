/*#include<iostream>
using namespace std;
int** allocatememory(int& rows, int& cols)
{
	int** matrix;
	matrix = new int* [rows];
	for (int i = 0; i < rows; i++)
	{
		*(matrix + i) = new int[cols];
	}
	return matrix;
}
void inputmatrix(int** matrix, const int rows, const int cols)
{
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			cin >> *(*(matrix + i) + j);
		}
	}
}
void Checkzeros(int** matrix, int rows, int cols)
{
	int* Ncol = new int[rows];   //You then create a dynamic 1D array called numbers to store the number of columns for each row. Each element in this array represents the number of columns in the corresponding row.

	int** MATRIX = new int* [rows];
	int count = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			if (*(*(matrix + i) + j) != 0)
			{
				count++;
				*(Ncol + i) = count;
			}
		}
		count = 0;
	}
	//allocation of non zero matrix
	for (int i = 0; i < rows; i++)
	{
		*(MATRIX + i) = new int[*(Ncol + i)];
	}
	//copying matrix
	int k = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < cols; j++)
		{
			if (*(*(matrix + i) + j) != 0)
			{
				*(*(MATRIX + i) + k) = *(*(matrix + i) + j);
				k++;
			}
		}
		k = 0;
	}
	cout << "new matrix" << endl;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < *(Ncol + i); j++)
		{
			cout << *(*(MATRIX + i) + j) << " ";
		}
		cout << endl;
	}
	for (int i = 0; i < rows; i++)
	{
		delete[] * (MATRIX + i);
	}
	delete[] MATRIX;
	delete[] Ncol;
}
void deallocate(int** matrix, int rows, int cols)
{
	for (int i = 0; i < rows; i++)
	{
		delete[] * (matrix + i);
	}
	delete[] matrix;
}
int main()
{
	int rows, cols, ** c;
	cout << "rows :";
	cin >> rows;
	cout << "cols :";
	cin >> cols;
	c = allocatememory(rows, cols);
	cout << "matrix" << endl;
	inputmatrix(c, rows, cols);
	Checkzeros(c, rows, cols);
	deallocate(c, rows, cols);
	system("pause");
	return 0;
}*/