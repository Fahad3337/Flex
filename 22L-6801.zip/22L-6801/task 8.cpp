#include<iostream>
#include<cctype>
using namespace std;
void letterFrequency(char* arr)
{
	int* Arr = new int[26];
	int count = 0;
	int k = 0;
	for (char i = 'a'; i <= 'z'; i++)
	{
		for (int j = 0; *(arr+j) != '\0'; j++)
		{
			if (tolower(i) == tolower(*(arr + j)))
			{
				count++;
				if (k < 26) {
					*(Arr+k) = count;
				}
			}
		}
		k++;
		count = 0;
	}
	int s = 0;
	for (char i = 'a'; i <= 'z'; i++)
	{
		bool conditionMet = false;
		for (int j = 0; *(arr + j) != '\0'; j++)
		{
			if (tolower(i) == tolower(*(arr + j)) && !conditionMet)
			{
				cout << i << ":" << *(Arr + s) << endl;
				conditionMet = true;
			}
		}
		s++;
	}
	delete[]Arr;
}
int main()
{
	char* arr = new char[100];
	cout << "input" << endl;
	cin.getline(arr, 100);
	cout << "output" << endl;
	letterFrequency(arr);
	delete[]arr;
	return 0;
}