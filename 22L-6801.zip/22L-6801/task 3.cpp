/*#include <iostream>
#include<climits>
using namespace std;
void inputArray(int* arr, int size)
{
    for (int i = 0; i < size; i++) {
        cin >> *(arr + i);
    }
}
int* removingDuplicates(int* arr, int size)
{
    for (int i = 0; i < size; i++) {
        for (int j = i + 1; j < size; j++) {
            if (*(arr + i) == *(arr + j)) {
                *(arr + j) = INT_MAX;
            }
        }
    }
    return arr;
}
int* copyingArrayandshow(int* arr1, int* arr2, int size1, int size2)
{
    int index = 0; int k = 0;
    int* arr3 = new int[index];
    for (int i = 0; i < size1; i++) {
        for (int j = 0; j < size2; j++) {
            if (*(arr1 + i) == *(arr2 + j) && *(arr1 + i) != INT_MAX) {
                *(arr3 + k) = *(arr1 + i);
                index++;
                k++;
            }
        }
    }
    for (int i = 0; i < index; i++) {
        cout << *(arr3 + i) << endl;
    }
    return arr3;
}
void Deallocation(int* arr)
{
    delete[]arr;
}
int main() {
    int size1, size2, * c, * d, * e;
    cout << "Size 1 : ";
    cin >> size1;
    cout << "Size 2 : ";
    cin >> size2;
    int* arr1 = new int[size1];
    int* arr2 = new int[size2];
    cout << "Array 1" << endl;
    inputArray(arr1, size1);
    cout << "Array 2" << endl;
    inputArray(arr2, size2);
    // Remove duplicates in arr1
    c = removingDuplicates(arr1, size1);
    // Remove duplicates in arr2
    d = removingDuplicates(arr2, size2);
    cout << "Common elements" << endl;
    e = copyingArrayandshow(c, d, size1, size2);
    Deallocation(arr1);
    Deallocation(arr2);
    Deallocation(e);
    system("pause");
    return 0;
}*/
