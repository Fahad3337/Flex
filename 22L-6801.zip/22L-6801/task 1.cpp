/*#include<iostream>
using namespace std;
void doublingSize(int*& arr, int& size)
{
	int newSize = size * 2;
	int* newArr = new int[newSize];
	for (int i = 0; i < size; i++) {
		*(newArr + i) = *(arr + i);
	}
	delete[] arr;
	arr = newArr;
	size = newSize;
}
void inputArrayandShow(int* arr, int size)
{
	int input;
	int count = 0;
	for (int i = 0; 1; i++)
	{
		cin >> input;
		if (input == -1)
		{
			break;
		}
		*(arr + count) = input;
		count++;
		if (count == size)
		{
			doublingSize(arr, size);
		}
	}
	cout << "output" << endl;
	for (int i = count - 1; i >= 0; i--)
	{
		cout << *(arr + i) << " ";
	}
	delete[]arr;
}

int main()
{
	int size;
	cout << "Size : ";
	cin >> size;
	int* arr = new int[size];
	cout << "input" << endl;
	inputArrayandShow(arr, size);
	system("pause");
	return 0;
}*/