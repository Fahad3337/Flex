/*#include<iostream>
using namespace std;
void fillArray(int** matrix, int rows, int* arr)
{
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < *(arr + i); j++)
		{
			cout << "Row " << i + 1 << ": ";
			cin >> *(*(matrix + i) + j);
		}
	}
}
int* twoDimToOneDim(int** matrix, int rows, int* arr)
{
	int count = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < *(arr + i); j++)
		{
			count++;
		}
	}
	int* Arr = new int[count];
	int k = 0;
	for (int i = 0; i < rows; i++)
	{
		for (int j = 0; j < *(arr + i); j++)
		{
			*(Arr + k) = *(*(matrix + i) + j);
			k++;
		}
	}
	return Arr;
}
int* SortArray(int* Arr, int count)
{
	int temp;
	for (int i = 0; i < count - 1; i++)
	{
		for (int j = i + 1; j < count; j++)
		{
			if (*(Arr + i) > *(Arr + j))
			{
				temp = *(Arr + i);
				*(Arr + i) = *(Arr + j);
				*(Arr + j) = temp;
			}
		}
	}
	return Arr;
}
void showArr(int* Arr, int count)
{
	for (int i = 0; i < count; i++)
	{
		cout << *(Arr + i) << " ";
	}
}
void DeallocationMatrix(int** matrix, int rows)
{
	for (int i = 0; i < rows; i++)
	{
		delete[] * (matrix + i);
	}
	delete[]matrix;
}
void DeallocationArray(int* arr)
{
	delete[]arr;
}
int main()
{
	int rows, * c, * d,count=0;
	cout << "rows : ";
	cin >> rows;
	int* arr = new int[rows];
	int** matrix = new int* [rows];
	for (int i = 0; i < rows; i++)
	{
		cout << "Cols at row " << i + 1 << " : ";
		cin >> *(arr + i);
		count += *(arr + i);
		*(matrix + i) = new int[*(arr + i)];
	}
	cout << endl << "Input Matrix" << endl;
	fillArray(matrix, rows, arr);
	c = twoDimToOneDim(matrix, rows, arr);
	DeallocationArray(arr);
	DeallocationMatrix(matrix, rows);
	d = SortArray(c, count);
	cout << endl << "Sorted Array" << endl;
	showArr(c, count);
	DeallocationArray(c);
	return 0;
}*/