
/*#include <iostream>
#include<climits>
using namespace std;
int* inputArray(int* arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cin >> *(arr+i);
    }
    return arr;
}
int* reducingDuplicates(int* arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (*(arr + i) == *(arr + j)) {
                *(arr + j) = INT_MAX;
            }
        }
    }
    return arr;
}
void outputArray(int* arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        if (*(arr + i) != INT_MAX) {
            cout << *(arr + i) << " ";
        }
    }
}
void Deallocation(int *arr)
{
    delete[]arr;
}
int main()
{
    int size, count = 0, * d, * e, * f;
    cout << "size : ";
    cin >> size;
    int* arr = new int[size];
    cout << "Input" << endl;
    e = inputArray(arr, size);
    cout << "Array before Compression" << endl;
    outputArray(e, size);
    d = reducingDuplicates(e, size);
    cout << endl << "Array after Compression" << endl;
    outputArray(d, size);
    Deallocation(arr);
    return 0;
}*/