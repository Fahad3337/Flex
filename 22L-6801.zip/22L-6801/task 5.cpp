/*#include<iostream>
using namespace std;
int** allocatememory(int& rows, int& cols)
{
	int** matrix;
	matrix = new int* [rows];
	for (int i = 0; i < rows; i++)
	{
		*(matrix + i) = new int[cols];
	}
	return matrix;
}
void intializematrix(int** matrix, const int rows, const int cols)
{
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			*(*(matrix + i) + j) = 0;
		}
	}
}
void displaymatrix(int** matrix, const int& rows, const int& cols)
{
	for (int i = 0; i < rows; i++) {
		for (int j = 0; j < cols; j++) {
			cout << *(*(matrix + i) + j) << " ";
		}
		cout << endl;
	}
}
void deallocatememory(int** matrix, const int& rows)
{
	for (int i = 0; i < rows; i++) {
		delete[] * (matrix + i);
	}
	delete[]matrix;
}
int main()
{
	int rows, cols, ** c;
	cout << "rows : ";
	cin >> rows;
	cout << "cols : ";
	cin >> cols;
	c = allocatememory(rows, cols);
	intializematrix(c, rows, cols);
	cout << "output" << endl;
	displaymatrix(c, rows, cols);
	deallocatememory(c, rows);
	return 0;
}*/