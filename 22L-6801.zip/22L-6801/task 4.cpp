/*#include<iostream>
using namespace std;
int* inputArray(int* arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cin >> *(arr + i);
    }
    return arr;
}
int* ascendingSorting(int* arr, int size)
{
    int temp;
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (*(arr + i) > *(arr + j))
            {
                temp = *(arr + i);
                *(arr + i) = *(arr + j);
                *(arr + j) = temp;
            }
        }
    }
    return arr;
}
int* descendingSorting(int* arr, int size)
{
    int temp;
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (*(arr + i) < *(arr + j))
            {
                temp = *(arr + i);
                *(arr + i) = *(arr + j);
                *(arr + j) = temp;
            }
        }
    }
    return arr;
}
int* mergingArray(int* arr1, int* arr2, int size1, int size2)
{

    int* arr3 = new int[size1 + size2];
    for (int i = 0; i < size1; i++) {
        *(arr3 + i) = *(arr1 + i);
    }
    for (int i = size1; i < size1 + size2; i++)
    {
        *(arr3 + i) = *(arr2 + i - size1);
    }
    return arr3;
}
int* finalSorting(int* arr, int size)
{
    int temp3;
    for (int i = 0; i < size - 1; i++)
    {
        for (int j = i + 1; j < size; j++)
        {
            if (*(arr + i) > *(arr + j))
            {
                temp3 = *(arr + i);
                *(arr + i) = *(arr + j);
                *(arr + j) = temp3;
            }
        }
    }
    return arr;
}
void showArray(int* arr, int size)
{
    for (int i = 0; i < size; i++)
    {
        cout << *(arr + i) << " ";
    }
}
void Deallocation(int* arr)
{
    delete[]arr;
}
int main()
{
    int size1, size2, * c, * d, * e, * f, * g, * h;
    cout << "size 1 : ";
    cin >> size1;
    cout << "size 2 : ";
    cin >> size2;
    int* arr1 = new int[size1];
    int* arr2 = new int[size2];
    cout << "Array 1 : ";
    c = inputArray(arr1, size1);
    cout << "Array 2 : ";
    d = inputArray(arr2, size2);
    e = ascendingSorting(c, size1);
    f = descendingSorting(d, size2);
    g = mergingArray(c, d, size1, size2);
    h = finalSorting(g, size1 + size2);
    cout << "Merged Array : ";
    showArray(h, size1 + size2);
    Deallocation(arr1);
    Deallocation(arr2);
    Deallocation(g);
    return 0;
}*/